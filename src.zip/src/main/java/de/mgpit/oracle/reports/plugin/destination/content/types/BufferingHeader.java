package de.mgpit.oracle.reports.plugin.destination.content.types;

public interface BufferingHeader extends Header {
    public final String SIZE_PROPERTY = "header.payload.bytesWritten";
}
