package de.mgpit.oracle.reports.plugin.destination.content.types;


public interface WithModel {

    // public Content getContentModel();

    public void setContentModel( Content content );

}
